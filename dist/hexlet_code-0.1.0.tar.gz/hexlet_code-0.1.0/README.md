### Hexlet tests and linter status:
[![Actions Status](https://github.com/chigorka/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/chigorka/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/e17b8db78706d7dcda40/maintainability)](https://codeclimate.com/github/chigorka/python-project-49/maintainability)
